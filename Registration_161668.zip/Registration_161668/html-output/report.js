$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/PersonalDetails.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Vineeth"
    }
  ],
  "line": 3,
  "name": "registration application",
  "description": "",
  "id": "registration-application",
  "keyword": "Feature"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on the personal details web page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 8,
  "name": "verify the title personal details",
  "description": "",
  "id": "registration-application;verify-the-title-personal-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "Check the heading of the page",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on the personal details web page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 11,
  "name": "verifying whether user enters first name",
  "description": "",
  "id": "registration-application;verifying-whether-user-enters-first-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 12,
  "name": "user leaves firstname blank and clicks the next button",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "display appropriate message for firstname",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on the personal details web page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 15,
  "name": "verifying whether user enters last name",
  "description": "",
  "id": "registration-application;verifying-whether-user-enters-last-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 16,
  "name": "user leaves lastname blank and clicks the next button",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "display appropriate message for lastname",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on the personal details web page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 19,
  "name": "verifying whether user enters email",
  "description": "",
  "id": "registration-application;verifying-whether-user-enters-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 20,
  "name": "user leaves email blank and clicks the next button",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "display appropriate message for email",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on the personal details web page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 24,
  "name": "verifying whether user enters contact number",
  "description": "",
  "id": "registration-application;verifying-whether-user-enters-contact-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 25,
  "name": "user leaves contact number blank and clicks the next button",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "display appropriate message for contact number",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on the personal details web page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 28,
  "name": "verifying whether user enters address line one",
  "description": "",
  "id": "registration-application;verifying-whether-user-enters-address-line-one",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 29,
  "name": "user leaves address line one blank and clicks the next button",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "display appropriate message for address line one",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on the personal details web page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 32,
  "name": "verifying whether user enters address line two",
  "description": "",
  "id": "registration-application;verifying-whether-user-enters-address-line-two",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 33,
  "name": "user leaves address line two blank and clicks the next button",
  "keyword": "When "
});
formatter.step({
  "line": 34,
  "name": "display appropriate message for address line two",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on the personal details web page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 36,
  "name": "verifying whether user selects city",
  "description": "",
  "id": "registration-application;verifying-whether-user-selects-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 37,
  "name": "user does not select city and clicks the next button",
  "keyword": "When "
});
formatter.step({
  "line": 38,
  "name": "display appropriate message for city",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on the personal details web page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 40,
  "name": "verifying whether user selects state",
  "description": "",
  "id": "registration-application;verifying-whether-user-selects-state",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 41,
  "name": "user does not select state and clicks the next button",
  "keyword": "When "
});
formatter.step({
  "line": 42,
  "name": "display appropriate message for state",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on the personal details web page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 44,
  "name": "when all the valid data is entered by user",
  "description": "",
  "id": "registration-application;when-all-the-valid-data-is-entered-by-user",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 45,
  "name": "all the valid data is entered by user",
  "keyword": "When "
});
formatter.step({
  "line": 46,
  "name": "navigate to educational details page",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.uri("features/PersonalEducationalDetails.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Vineeth"
    }
  ],
  "line": 3,
  "name": "registration education application",
  "description": "",
  "id": "registration-education-application",
  "keyword": "Feature"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on the educational details web page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinitionEducationDetails.user_is_on_the_educational_details_web_page()"
});
formatter.result({
  "duration": 3319610834,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "verify the title educational details",
  "description": "",
  "id": "registration-education-application;verify-the-title-educational-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "Check the heading of the educational details page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionEducationDetails.check_the_heading_of_the_educational_details_page()"
});
formatter.result({
  "duration": 3193336489,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "user is on the educational details web page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinitionEducationDetails.user_is_on_the_educational_details_web_page()"
});
