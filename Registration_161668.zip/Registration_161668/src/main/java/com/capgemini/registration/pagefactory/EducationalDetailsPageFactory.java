package com.capgemini.registration.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class EducationalDetailsPageFactory {
	
	WebDriver wd;
	
	public EducationalDetailsPageFactory(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[1]/td[2]/select")
	@CacheLookup
	WebElement  graduation;
	
	@FindBy(name="percentage")
	@CacheLookup
	WebElement  percentage;
	
	@FindBy(name="passingYear")
	@CacheLookup
	WebElement  passingYear;
	
	@FindBy(name="projectName")
	@CacheLookup
	WebElement  projectName;
	
	@FindBy(xpath="//*[@id=\".net\"]")
	@CacheLookup
	WebElement net;
	
	@FindBy(xpath="//*[@id=\"java\"]")
	@CacheLookup
	WebElement java;
	
	@FindBy(xpath="//*[@id=\"php\"]")
	@CacheLookup
	WebElement php;
	
	@FindBy(xpath="//*[@id=\"other\"]")
	@CacheLookup
	WebElement other;
	
	@FindBy(name="otherTechnologies")
	@CacheLookup
	WebElement  otherTechnologies;
	
	@FindBy(xpath="//*[@id=\"btnRegister\"]")
	@CacheLookup
	WebElement  button;
	
	public Select getSelectOptions(WebElement select) {
		  return new Select(select);
		}

	public void setGraduation(String value) {
		getSelectOptions(graduation).selectByVisibleText(value);
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public void setNet() {
		net.click();
	}

	public void setJava() {
		java.click();
	}

	public void setPhp() {
		php.click();
	}

	public void setOther() {
		other.click();
	}

	public void setOtherTechnologies(String otherTechnologies) {
		this.otherTechnologies.sendKeys(otherTechnologies);
	}

	public void setButton() {
		button.click();
	}

	

}
