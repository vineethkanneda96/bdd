package com.capgemini.registration.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PersonalDetailsPageFactory {
	
	WebDriver wd;
	
	public PersonalDetailsPageFactory(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(name="Email")
	@CacheLookup
	WebElement email;
	
	@FindBy(name="Phone")
	@CacheLookup
	WebElement phone;
	
	@FindBy(name="address1")
	@CacheLookup
	WebElement address1;
	
	@FindBy(name="address2")
	@CacheLookup
	WebElement address2;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[9]/td[2]/select")
	@CacheLookup
	WebElement  city;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[10]/td[2]/select")
	@CacheLookup
	WebElement  state;
	
	@FindBy(linkText="Next")
	@CacheLookup
	WebElement  next;
	
	public Select getSelectOptions(WebElement select) {
		  return new Select(select);
		}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}

	public void setAddress1(String address1) {
		this.address1.sendKeys(address1);
	}

	public void setAddress2(String address2) {
		this.address2.sendKeys(address2);
	}

	public void setCity(String value) {
		getSelectOptions(city).selectByVisibleText(value);
	}

	public void setState(String value) {
		getSelectOptions(state).selectByVisibleText(value);
	}

	public void setNext() {
		next.click();
	}

	

}
