package com.capgemini.registration.educationdetails;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.registration.pagefactory.EducationalDetailsPageFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitionEducationDetails {


	private EducationalDetailsPageFactory educationalDetails; 
	private WebDriver driver;

	@Given("^user is on the educational details web page$")
	public void user_is_on_the_educational_details_web_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		driver = new ChromeDriver();
		educationalDetails=new EducationalDetailsPageFactory(driver);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.get("file:///D:/SpringPrograms/Registration_161668/src/test/java/com/capgemini/registration/educationdetails/EducationalDetails.html");
	}

	@Then("^Check the heading of the educational details page$")
	public void check_the_heading_of_the_educational_details_page() throws Throwable {
		String strheading=driver.findElement(By.xpath("/html/body/h4")).getText();
		if(strheading.contentEquals("Step 2: Educational Details"))
			System.out.println("********** Heading Matched");
		else
			System.out.println("********** Heading Not Matched");
		Thread.sleep(3000);
		driver.close();
	}

	@When("^user does not selects graduation and clicks the next button$")
	public void user_does_not_selects_graduation_and_clicks_the_next_button() throws Throwable {
		educationalDetails.setButton();
		Thread.sleep(3000);
	}

	@Then("^display appropriate message for graduation$")
	public void display_appropriate_message_for_graduation() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please Select Graduation");
		System.out.println("*******************"+alertMessage);
		driver.close();
	}

	@When("^user leaves percentage blank and clicks the next button$")
	public void user_leaves_percentage_blank_and_clicks_the_next_button() throws Throwable {
		educationalDetails.setGraduation("BE");
		Thread.sleep(3000);
		educationalDetails.setPercentage("");
		educationalDetails.setButton();
		Thread.sleep(3000);
	}

	@Then("^display appropriate message for percentage$")
	public void display_appropriate_message_for_percentage() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please fill Percentage detail");
		System.out.println("*******************"+alertMessage);
		driver.close();
	}

	@When("^user leaves passing year blank and clicks the next button$")
	public void user_leaves_passing_year_blank_and_clicks_the_next_button() throws Throwable {
		educationalDetails.setGraduation("BE");
		Thread.sleep(3000);
		educationalDetails.setPercentage("80");
		Thread.sleep(3000);
		educationalDetails.setPassingYear("");
		Thread.sleep(3000);
		educationalDetails.setButton();
		Thread.sleep(3000);
	}

	@Then("^display appropriate message for passing year$")
	public void display_appropriate_message_for_passing_year() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please fill Passing Year");
		System.out.println("*******************"+alertMessage);
		driver.close();
	}

	@When("^user leaves project name blank and clicks the next button$")
	public void user_leaves_project_name_blank_and_clicks_the_next_button() throws Throwable {
		educationalDetails.setGraduation("BE");
		Thread.sleep(3000);
		educationalDetails.setPercentage("80");
		Thread.sleep(3000);
		educationalDetails.setPassingYear("2018");
		Thread.sleep(3000);
		educationalDetails.setProjectName("");
		Thread.sleep(3000);
		educationalDetails.setButton();
		Thread.sleep(3000);
	}

	@Then("^display appropriate message for project name$")
	public void display_appropriate_message_for_project_name() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please fill Project Name");
		System.out.println("*******************"+alertMessage);
		driver.close();
	}

	@When("^user leaves does not select technologies used and clicks the next button$")
	public void user_leaves_does_not_select_technologies_used_and_clicks_the_next_button() throws Throwable {
		educationalDetails.setGraduation("BE");
		Thread.sleep(3000);
		educationalDetails.setPercentage("80");
		Thread.sleep(3000);
		educationalDetails.setPassingYear("2018");
		Thread.sleep(3000);
		educationalDetails.setProjectName("Aeroplane");
		Thread.sleep(3000);
		educationalDetails.setButton();
		Thread.sleep(3000);
	}

	@Then("^display appropriate message for technologies used$")
	public void display_appropriate_message_for_technologies_used() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please Select Technologies Used");
		System.out.println("*******************"+alertMessage);
		driver.close();
		Thread.sleep(3000);
	}

	@When("^user leaves other technologies blank and clicks the next button$")
	public void user_leaves_other_technologies_blank_and_clicks_the_next_button() throws Throwable {
		educationalDetails.setGraduation("BE");
		Thread.sleep(3000);
		educationalDetails.setPercentage("80");
		Thread.sleep(3000);
		educationalDetails.setPassingYear("2018");
		Thread.sleep(3000);
		educationalDetails.setProjectName("Aeroplane");
		Thread.sleep(3000);
		educationalDetails.setOther();
		Thread.sleep(3000);
		educationalDetails.setOtherTechnologies("");
		Thread.sleep(3000);
		educationalDetails.setButton();
		Thread.sleep(3000);
	}

	@Then("^display appropriate message for other technologies used$")
	public void display_appropriate_message_for_other_technologies_used() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please fill other Technologies Used");
		System.out.println("*******************"+alertMessage);
		driver.close();
		Thread.sleep(3000);
	}

	@When("^all the data is entered by user is correct$")
	public void all_the_data_is_entered_by_user_is_correct() throws Throwable {
		educationalDetails.setGraduation("BE");
		Thread.sleep(3000);
		educationalDetails.setPercentage("80");
		Thread.sleep(3000);
		educationalDetails.setPassingYear("2018");
		Thread.sleep(3000);
		educationalDetails.setProjectName("Aeroplane");
		Thread.sleep(3000);
		educationalDetails.setJava();
		Thread.sleep(3000);
		educationalDetails.setButton();
		Thread.sleep(3000);
	}

	@Then("^display registration successfull$")
	public void display_registration_successfull() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Your Registration Has succesfully done Plz check you registerd email for account activation link !!!");
		System.out.println("*******************"+alertMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

}
