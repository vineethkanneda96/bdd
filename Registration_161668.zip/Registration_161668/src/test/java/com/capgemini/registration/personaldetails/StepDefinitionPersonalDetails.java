package com.capgemini.registration.personaldetails;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.registration.pagefactory.PersonalDetailsPageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitionPersonalDetails {
	
	private PersonalDetailsPageFactory personalDetails;
	private WebDriver driver;
	
	@Given("^user is on the personal details web page$")
	public void user_is_on_the_personal_details_web_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\Drivers\\BDD Jar Files\\chromedriver.exe");
		driver = new ChromeDriver();
		personalDetails=new PersonalDetailsPageFactory(driver);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.get("file:///D:/SpringPrograms/Registration_161668/src/test/java/com/capgemini/registration/personaldetails/PersonalDetails.html");
	}

	@Then("^Check the heading of the page$")
	public void check_the_heading_of_the_page() throws Throwable {
		String strheading=driver.findElement(By.xpath("/html/body/h4")).getText();
	    if(strheading.contentEquals("Step 1: Personal Details"))
	    	System.out.println("********** Heading Matched");
	    else
	    	System.out.println("********** Heading Not Matched");
	    driver.close();
	}

	@When("^user leaves firstname blank and clicks the next button$")
	public void user_leaves_firstname_blank_and_clicks_the_next_button() throws Throwable {
	    
	    personalDetails.setFirstName("");
	    
	    personalDetails.setNext();
	    Thread.sleep(3000);
	}

	@Then("^display appropriate message for firstname$")
	public void display_appropriate_message_for_firstname() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
	    assertEquals(alertMessage, "Please fill the First Name");
	    System.out.println("*******************"+alertMessage);
	    driver.close();
	    
	}

	@When("^user leaves lastname blank and clicks the next button$")
	public void user_leaves_lastname_blank_and_clicks_the_next_button() throws Throwable {
		Thread.sleep(2000);
	    personalDetails.setFirstName("Vineeth");
	  
	    personalDetails.setLastName("");
	    personalDetails.setNext();
	    Thread.sleep(3000);
	    
	}

	@Then("^display appropriate message for lastname$")
	public void display_appropriate_message_for_lastname() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
	    assertEquals(alertMessage, "Please fill the Last Name");
	    System.out.println("*******************"+alertMessage);
	    driver.close();
	    Thread.sleep(3000);
	}

	@When("^user leaves email blank and clicks the next button$")
	public void user_leaves_email_blank_and_clicks_the_next_button() throws Throwable {
		Thread.sleep(2000);
	    personalDetails.setFirstName("Vineeth");
	   
	    personalDetails.setLastName("Kumar");
	   
	    personalDetails.setEmail("");
	    personalDetails.setNext();
	    Thread.sleep(3000);
	}

	@Then("^display appropriate message for email$")
	public void display_appropriate_message_for_email() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
	    assertEquals(alertMessage, "Please fill the Email");
	    System.out.println("*******************"+alertMessage);
	    driver.close();
	}

	@When("^user leaves contact number blank and clicks the next button$")
	public void user_leaves_contact_number_blank_and_clicks_the_next_button() throws Throwable {
		Thread.sleep(2000);
	    personalDetails.setFirstName("Vineeth");
	   
	    personalDetails.setLastName("Kumar");
	   
	    personalDetails.setEmail("vineeth@gmail.com");
	   
	    personalDetails.setPhone("");
	    personalDetails.setNext();
	    Thread.sleep(3000);
	}

	@Then("^display appropriate message for contact number$")
	public void display_appropriate_message_for_contact_number() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
	    assertEquals(alertMessage, "Please fill the Contact No.");
	    System.out.println("*******************"+alertMessage);
	    driver.close();
	}

	@When("^user leaves address line one blank and clicks the next button$")
	public void user_leaves_address_line_one_blank_and_clicks_the_next_button() throws Throwable {
		Thread.sleep(2000);
	    personalDetails.setFirstName("Vineeth");
	   
	    personalDetails.setLastName("Kumar");
	   
	    personalDetails.setEmail("vineeth@gmail.com");
	   
	    personalDetails.setPhone("9999999999");
	    personalDetails.setAddress1("");
	    personalDetails.setNext();
	    Thread.sleep(3000);
	}

	@Then("^display appropriate message for address line one$")
	public void display_appropriate_message_for_address_line_one() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
	    assertEquals(alertMessage, "Please fill the address line 1");
	    System.out.println("*******************"+alertMessage);
	    driver.close();
	}

	@When("^user leaves address line two blank and clicks the next button$")
	public void user_leaves_address_line_two_blank_and_clicks_the_next_button() throws Throwable {
		Thread.sleep(2000);
	    personalDetails.setFirstName("Vineeth");
	   
	    personalDetails.setLastName("Kumar");
	   
	    personalDetails.setEmail("vineeth@gmail.com");
	   
	    personalDetails.setPhone("9999999999");
	    personalDetails.setAddress1("7-1-100 gachibowli");
	    personalDetails.setAddress2("");
	    personalDetails.setNext();
	    Thread.sleep(3000);
	}

	@Then("^display appropriate message for address line two$")
	public void display_appropriate_message_for_address_line_two() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
	    assertEquals(alertMessage, "Please fill the address line 2");
	    System.out.println("*******************"+alertMessage);
	    driver.close();
	}
    
	@When("^user does not select city and clicks the next button$")
	public void user_does_not_select_city_and_clicks_the_next_button() throws Throwable {
		Thread.sleep(2000);
	    personalDetails.setFirstName("Vineeth");

	    personalDetails.setLastName("Kumar");
	 
	    personalDetails.setEmail("vineeth@gmail.com");
	   
	    personalDetails.setPhone("9999999999");
	    personalDetails.setAddress1("7-1-100 gachibowli");
	    personalDetails.setAddress2("srnagar");
	    //personalDetails.setCity("");
	    personalDetails.setNext();
	    Thread.sleep(3000);
	}

	@Then("^display appropriate message for city$")
	public void display_appropriate_message_for_city() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
	    assertEquals(alertMessage, "Please select city");
	    System.out.println("*******************"+alertMessage);
	    driver.close();
	}

	@When("^user does not select state and clicks the next button$")
	public void user_does_not_select_state_and_clicks_the_next_button() throws Throwable {
		Thread.sleep(2000);
	    personalDetails.setFirstName("Vineeth");
	   
	    personalDetails.setLastName("Kumar");
	    
	    personalDetails.setEmail("vineeth@gmail.com");
	    
	    personalDetails.setPhone("9999999999");
	 
	    personalDetails.setAddress1("7-1-100 gachibowli");
	 
	    personalDetails.setAddress2("srnagar");
	   
	    personalDetails.setCity("Hyderabad");
	  
	    personalDetails.setNext();
	    Thread.sleep(3000);
	}

	@Then("^display appropriate message for state$")
	public void display_appropriate_message_for_state() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
	    assertEquals(alertMessage, "Please select state");
	    System.out.println("*******************"+alertMessage);
	    driver.close();
	}

	@When("^all the valid data is entered by user$")
	public void all_the_valid_data_is_entered_by_user() throws Throwable {
		Thread.sleep(2000);
	    personalDetails.setFirstName("Vineeth");
	   
	    personalDetails.setLastName("Kumar");
	  
	    personalDetails.setEmail("vineeth@gmail.com");
	    
	    personalDetails.setPhone("9999999999");
	    personalDetails.setAddress1("7-1-100 gachibowli");
	    personalDetails.setAddress2("srnagar");
	  
	    personalDetails.setCity("Hyderabad");
	   
	    personalDetails.setState("Telangana");
	    personalDetails.setNext();
	    Thread.sleep(3000);
	}

	@Then("^navigate to educational details page$")
	public void navigate_to_educational_details_page() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Personal details are validated and accepted successfully.");
	    System.out.println("*******************"+alertMessage);
	    driver.switchTo().alert().accept();
		driver.navigate().to("file:///D:/SpringPrograms/Registration_161668/src/test/java/com/capgemini/registration/educationdetails/EducationalDetails.html");
		Thread.sleep(2000);
		System.out.println("\n********************* Successfully Entered to educational details page ");
		driver.close();
	}

}
