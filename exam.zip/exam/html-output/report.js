$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/loan.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author:"
    }
  ],
  "line": 2,
  "name": "enter details in loan form",
  "description": "",
  "id": "enter-details-in-loan-form",
  "keyword": "Feature"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "user login is validated and redirected to HTML Form Demo",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefLoan.user_login_is_validated_and_redirected_to_HTML_Form_Demo()"
});
formatter.result({
  "duration": 4318442104,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "Verify the title as HTML Form Demo",
  "description": "",
  "id": "enter-details-in-loan-form;verify-the-title-as-html-form-demo",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "Title is verified",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefLoan.title_is_verified()"
});
formatter.result({
  "duration": 405917267,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "user login is validated and redirected to HTML Form Demo",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefLoan.user_login_is_validated_and_redirected_to_HTML_Form_Demo()"
});
formatter.result({
  "duration": 3487882458,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Successful login with all valid data",
  "description": "",
  "id": "enter-details-in-loan-form;successful-login-with-all-valid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "user enters all the valid data",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "navigate to success page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefLoan.user_enters_all_the_valid_data()"
});
formatter.result({
  "duration": 7303364138,
  "status": "passed"
});
formatter.match({
  "location": "StepDefLoan.navigate_to_success_page()"
});
formatter.result({
  "duration": 3251931626,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "user login is validated and redirected to HTML Form Demo",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefLoan.user_login_is_validated_and_redirected_to_HTML_Form_Demo()"
});
formatter.result({
  "duration": 2717533987,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Failure in loan page on leaving first Name blank",
  "description": "",
  "id": "enter-details-in-loan-form;failure-in-loan-page-on-leaving-first-name-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user leaves first name blank and clicks the button",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "display error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefLoan.user_leaves_first_name_blank_and_clicks_the_button()"
});
formatter.result({
  "duration": 290817156,
  "status": "passed"
});
formatter.match({
  "location": "StepDefLoan.display_error_message()"
});
