package features;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.project.exam.Login;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDeflogin {
	private Login exam;
	private WebDriver driver;
	
@Given("^user is on the webpage$")
public void user_is_on_the_webpage() throws Throwable {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\asus\\Downloads\\chromedriver.exe");
	driver = new ChromeDriver();
	exam=new Login(driver);
    driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    driver.get("file:///C:/workspace/exam/src/test/java/features/login.html");
}

@Then("^check the heading of the page$")
public void check_the_heading_of_the_page() throws Throwable {
	 String strheading=driver.findElement(By.xpath(".//*[@id='mainCnt']/div[1]/div[1]/h1")).getText();
	    if(strheading.contentEquals("Hotel Booking Application"))
	    	System.out.println("********** Heading Matched");
	    else
	    	System.out.println("********** Heading Not Matched");
	    Thread.sleep(5000);
	    
	    driver.findElement(By.partialLinkText("SPAM")).click();
	    Thread.sleep(3000);
	    driver.close();
}

@When("^user enter all valid details$")
public void user_enter_all_valid_details() throws Throwable {
	exam.setUsername("capgemini");
    exam.setUserPwd("capg1234");
    Thread.sleep(5000);
    exam.setOther();
    Thread.sleep(3000);
    exam.setAge();
    Thread.sleep(3000); 
    exam.setTerms();
	System.out.print("Gender is : ");
	if(driver.findElement(By.id("male")).isSelected())
	{
		System.out.print("male");
	}
	else if(driver.findElement(By.id("female")).isSelected())
	{
		System.out.println("female");
	}
	else if(driver.findElement(By.id("other")).isSelected())
	{
		System.out.println("other");
	}
	exam.setLogin();
}

@Then("^navigate to loan page$")
public void navigate_to_loan_page() throws Throwable {
	driver.navigate().to("file:///C:/workspace/exam/src/test/java/features/loan.html");
	Thread.sleep(2000);
	System.out.println("\n********************* Login Success");
	driver.close();
}

@When("^user leaves username blank and click the button$")
public void user_leaves_username_blank_and_click_the_button() throws Throwable {
	Thread.sleep(2000);
   exam.setUsername("");
   Thread.sleep(2000);
   exam.setLogin();
   System.out.println("* Please enter userName.");
}

@Then("^display appropriate message$")
public void display_appropriate_message() throws Throwable {
	String str=driver.findElement(By.xpath(".//*[@id='userErrMsg']")).getText();
	 assertEquals(str, "* Please enter userName.");
	   
	    driver.close();
    }

@When("^user leaves password blank and click the button$")
public void user_leaves_password_blank_and_click_the_button() throws Throwable {
	exam.setUsername("capgemini");
	  Thread.sleep(2000);
	   exam.setUserPwd("");
	   Thread.sleep(2000);
	   exam.setLogin(); 
	   System.out.println("* Please enter password.");
}
@Then("^display appropriate messages$")
public void display_appropriate_messages() throws Throwable {
	String str=driver.findElement(By.xpath("//*[@id=\"pwdErrMsg\"]")).getText();
	 assertEquals(str, "* Please enter password.");
	   
	    driver.close();
  }

@When("^user enters incorrect username or password$")
public void user_enters_incorrect_username_or_password() throws Throwable {
	exam.setUsername("capge");
	Thread.sleep(2000);
	   exam.setUserPwd("1234");
	   Thread.sleep(2000);
	   exam.setLogin();  
}

@Then("^display login failed message$")
public void display_login_failed_message() throws Throwable {
	String alertMessage=driver.switchTo().alert().getText();
    driver.switchTo().alert().accept();
    System.out.println("*******************"+alertMessage);
    driver.close();
}

}
