package features;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.project.exam.loan;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefLoan {
	private loan loan;
	private WebDriver driver;
	
	@Given("^user login is validated and redirected to HTML Form Demo$")
	public void user_login_is_validated_and_redirected_to_HTML_Form_Demo() throws Throwable {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\asus\\Downloads\\chromedriver.exe");
		driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		loan = new loan(driver);
		driver.get("file:///C:/workspace/exam/src/test/java/features/loan.html");
	}

	@Then("^Title is verified$")
	public void title_is_verified() throws Throwable {
		 if(driver.getTitle().contentEquals("HTML Form Demo"))
			   System.out.println("********** Title Matched");
		   else
			   System.out.println("*********** Title mismatch");
		   
		   driver.close();
	}

	@When("^user enters all the valid data$")
	public void user_enters_all_the_valid_data() throws Throwable {
	    loan.setFname("vineeth");
	    Thread.sleep(1000);
	    loan.setLname("kumar");
	    loan.setDob("12/03/1996");
	    loan.setMale();
	    loan.setEnglish();
	    loan.setHindi();
	    Thread.sleep(1000);
	    loan.setAddress("sdsdjwdnkjdk jwhejfhejr");
	    loan.setCity("Pune");
	    loan.setPhno("9876543212");
	    loan.setAccno("12345");
	    Thread.sleep(1000);
	    loan.setPan("ABCDE1234F");
	    loan.setCredit("8888888888888888");
	    Thread.sleep(1000);
	    loan.setNoofyr("3");
	    loan.setRoi("1");
	    loan.setAmount("2000");
	    loan.setLoantype("Personal");
	    Thread.sleep(1000);
	    loan.setEmail("hdbcdjnfjdn@gmail.com");
	}

	@Then("^navigate to success page$")
	public void navigate_to_success_page() throws Throwable {
		loan.setSubmit();
		    System.out.println("all Valid Credentials");
			driver.navigate().to("file:///C:/workspace/exam/src/test/java/features/success.html");
			Thread.sleep(3000);
			System.out.println("loan Confirmed");
			driver.close();
	}

	@When("^user leaves first name blank and clicks the button$")
	public void user_leaves_first_name_blank_and_clicks_the_button() throws Throwable {
		   loan.setFname("");
		   loan.setSubmit();
	    	}

	@When("^user leaves last name blank and clicks the button$")
	public void user_leaves_last_name_blank_and_clicks_the_button() throws Throwable {
		 loan.setFname("vineeth");
		 loan.setLname("");
		   loan.setSubmit(); 
	}

	@When("^user leaves dateofbirth blank$")
	public void user_leaves_dateofbirth_blank() throws Throwable {
		loan.setFname("vineeth");
	    Thread.sleep(1000);
	    loan.setLname("kumar");
	    loan.setDob("");
	    loan.setSubmit();
	   
	}
	
	@When("^gender is not selected$")
	public void gender_is_not_selected() throws Throwable {
		loan.setFname("vineeth");
	    Thread.sleep(1000);
	    loan.setLname("kumar");
	    loan.setDob("12/03/1996");
	    loan.setSubmit();
	}

	@When("^languages known is empty$")
	public void languages_known_is_empty() throws Throwable {
		 loan.setFname("vineeth");
		    Thread.sleep(1000);
		    loan.setLname("kumar");
		    loan.setDob("12/03/1996");
		    loan.setMale();
		    //loan.setEnglish();
		    Thread.sleep(1000);
		    loan.setSubmit();
	}

	@When("^address is empty$")
	public void address_is_empty() throws Throwable {
		 loan.setFname("vineeth");
		    Thread.sleep(1000);
		    loan.setLname("kumar");
		    loan.setDob("12/03/1996");
		    loan.setMale();
		    loan.setEnglish();
		    loan.setAddress("");
		    Thread.sleep(1000);
		    loan.setSubmit();
	}

	@When("^city is not selected$")
	public void city_is_not_selected() throws Throwable {
		 loan.setFname("vineeth");
		    Thread.sleep(1000);
		    loan.setLname("kumar");
		    loan.setDob("12/03/1996");
		    loan.setMale();
		    loan.setEnglish();
		    Thread.sleep(1000);
		    loan.setAddress("habsnb sdjbsbffenmf");
		   // loan.setCity("");
		    loan.setSubmit();
		    
	}

	@When("^mobileNumber is empty$")
	public void mobilenumber_is_empty() throws Throwable {
		loan.setFname("vineeth");
	    Thread.sleep(1000);
	    loan.setLname("kumar");
	    loan.setDob("12/03/1996");
	    loan.setMale();
	    loan.setEnglish();
	    Thread.sleep(1000);
	    loan.setAddress("habsnb sdjbsbffenmf");
	    loan.setCity("Pune");
	    loan.setPhno("");
		loan.setSubmit();
	}

	@When("^AccountNumber is empty$")
	public void accountnumber_is_empty() throws Throwable {
		 loan.setFname("vineeth");
		    Thread.sleep(1000);
		    loan.setLname("kumar");
		    loan.setDob("12/03/1996");
		    loan.setMale();
		    loan.setEnglish();
		    Thread.sleep(1000);
		    loan.setAddress("habsnb sdjbsbffenmf");
		    loan.setCity("Pune");
		    loan.setPhno("9876543212");
		    loan.setAccno("");
		    Thread.sleep(1000);
		loan.setSubmit();
	}

	@When("^PanNumber is empty$")
	public void pannumber_is_empty() throws Throwable {
		 loan.setFname("vineeth");
		    Thread.sleep(1000);
		    loan.setLname("kumar");
		    loan.setDob("12/03/1996");
		    loan.setMale();
		    loan.setEnglish();
		    Thread.sleep(1000);
		    loan.setAddress("habsnb sdjbsbffenmf");
		    loan.setCity("Pune");
		    loan.setPhno("9876543212");
		    loan.setAccno("12345");
		    loan.setPan("");
		    Thread.sleep(1000);
		loan.setSubmit();    
	}

	@When("^creditcardNumber is empty$")
	public void creditcardnumber_is_empty() throws Throwable {
		loan.setFname("vineeth");
	    Thread.sleep(1000);
	    loan.setLname("kumar");
	    loan.setDob("12/03/1996");
	    loan.setMale();
	    loan.setEnglish();
	    Thread.sleep(1000);
	    loan.setAddress("habsnb sdjbsbffenmf");
	    loan.setCity("Pune");
	    loan.setPhno("9876543212");
	    loan.setAccno("12345");
	    Thread.sleep(1000);
	    loan.setPan("ABCDE1234F");
	    loan.setCredit("");
	    Thread.sleep(1000);
	    
	
		loan.setSubmit();
	}

	@When("^numberofyears is empty$")
	public void numberofyears_is_empty() throws Throwable {
		loan.setFname("vineeth");
	    Thread.sleep(1000);
	    loan.setLname("kumar");
	    loan.setDob("12/03/1996");
	    loan.setMale();
	    loan.setEnglish();
	    Thread.sleep(1000);
	    loan.setAddress("habsnb sdjbsbffenmf");
	    loan.setCity("Pune");
	    loan.setPhno("9876543212");
	    loan.setAccno("12345");
	    Thread.sleep(1000);
	    loan.setPan("ABCDE1234F");
	    loan.setCredit("8888888888888888");
	    Thread.sleep(1000);
	    loan.setNoofyr("");
	    	loan.setSubmit();
	}

	@When("^rateofinterest is empty$")
	public void rateofinterest_is_empty() throws Throwable {
		loan.setFname("vineeth");
	    Thread.sleep(1000);
	    loan.setLname("kumar");
	    loan.setDob("12/03/1996");
	    loan.setMale();
	    loan.setEnglish();
	    Thread.sleep(1000);
	    loan.setAddress("habsnb sdjbsbffenmf");
	    loan.setCity("Pune");
	    loan.setPhno("9876543212");
	    loan.setAccno("12345");
	    Thread.sleep(1000);
	    loan.setPan("ABCDE1234F");
	    loan.setCredit("8888888888888888");
	    Thread.sleep(1000);
	    loan.setNoofyr("3");
	    loan.setRoi("");
	
		loan.setSubmit(); 
	}

	@When("^loanamount is empty$")
	public void loanamount_is_empty() throws Throwable {
		loan.setFname("vineeth");
	    Thread.sleep(1000);
	    loan.setLname("kumar");
	    loan.setDob("12/03/1996");
	    loan.setMale();
	    loan.setEnglish();
	    Thread.sleep(1000);
	    loan.setAddress("habsnb sdjbsbffenmf");
	    loan.setCity("Pune");
	    loan.setPhno("9876543212");
	    loan.setAccno("12345");
	    Thread.sleep(1000);
	    loan.setPan("ABCDE1234F");
	    loan.setCredit("8888888888888888");
	    Thread.sleep(1000);
	    loan.setNoofyr("3");
	    loan.setRoi("1");
	    loan.setAmount("");
	
	    Thread.sleep(1000);
	    
	
		loan.setSubmit(); 
	}
	
	@When("^loantype is not selected$")
	public void loantype_is_not_selected() throws Throwable {
		loan.setFname("vineeth");
	    Thread.sleep(1000);
	    loan.setLname("kumar");
	    loan.setDob("12/03/1996");
	    loan.setMale();
	    loan.setEnglish();
	    Thread.sleep(1000);
	    loan.setAddress("habsnb sdjbsbffenmf");
	    loan.setCity("Pune");
	    loan.setPhno("9876543212");
	    loan.setAccno("12345");
	    Thread.sleep(1000);
	    loan.setPan("ABCDE1234F");
	    loan.setCredit("8888888888888888");
	    Thread.sleep(1000);
	    loan.setNoofyr("3");
	    loan.setRoi("1");
	    loan.setAmount("2000");
	   // loan.setLoantype("");
	    Thread.sleep(1000);
	   loan.setSubmit();
	
	    
	}

	@When("^emailid is empty$")
	public void emailid_is_empty() throws Throwable {
		loan.setFname("vineeth");
	    Thread.sleep(1000);
	    loan.setLname("kumar");
	    loan.setDob("12/03/1996");
	    loan.setMale();
	    loan.setEnglish();
	    Thread.sleep(1000);
	    loan.setAddress("habsnb sdjbsbffenmf");
	    loan.setCity("Pune");
	    loan.setPhno("9876543212");
	    loan.setAccno("12345");
	    Thread.sleep(1000);
	    loan.setPan("ABCDE1234F");
	    loan.setCredit("8888888888888888");
	    Thread.sleep(1000);
	    loan.setNoofyr("3");
	    loan.setRoi("1");
	    loan.setAmount("2000");
	    loan.setLoantype("Personal");
	    Thread.sleep(1000);
	    loan.setEmail("");
	
		loan.setSubmit();
	    	}
	
	@Then("^display error message$")
	public void display_error_message() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}


}
