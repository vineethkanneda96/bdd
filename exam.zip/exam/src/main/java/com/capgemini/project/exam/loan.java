package com.capgemini.project.exam;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class loan {
	WebDriver wd;
	public loan(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}
	
	
	@FindBy(name="fname")
	@CacheLookup
	WebElement  fname;
	
	@FindBy(name="lname")
	@CacheLookup
	WebElement  lname;
	
	@FindBy(name="dob")
	@CacheLookup
	WebElement  dob;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[4]/td[2]/input[1]")
	@CacheLookup
	WebElement  male;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[4]/td[2]/input[2]")
	@CacheLookup
	WebElement  female;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[5]/td[2]/input[1]")
	@CacheLookup
	WebElement English;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[5]/td[2]/input[2]")
	@CacheLookup
	WebElement  Hindi;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[5]/td[2]/input[3]")
	@CacheLookup
	WebElement  French;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/textarea")
	@CacheLookup
	WebElement  address;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[7]/td[2]/select")
	@CacheLookup
	WebElement  city;
	
	public Select getSelectOptions(WebElement select) {
		  return new Select(select);
		}
	
	@FindBy(name="phno")
	@CacheLookup
	WebElement  phno;
	
	@FindBy(name="accno")
	@CacheLookup
	WebElement  accno;
	
	@FindBy(name="PAN")
	@CacheLookup
	WebElement  pan;
	
	@FindBy(name="credit")
	@CacheLookup
	WebElement  credit;
	
	@FindBy(name="noofyr")
	@CacheLookup
	WebElement  noofyr;
	
	@FindBy(name="roi")
	@CacheLookup
	WebElement  roi;
	
	@FindBy(name="amt")
	@CacheLookup
	WebElement  amount;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[16]/td[2]/select")
	@CacheLookup
	WebElement  loantype;
	
	@FindBy(name="emailid")
	@CacheLookup
	WebElement  email;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[18]/td[1]/input")
	@CacheLookup
	WebElement submit;
	
	public WebElement getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}

	public WebElement getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname.sendKeys(lname);
	}

	public WebElement getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob.sendKeys(dob);
	}

	public WebElement getMale() {
		return male;
	}

	public void setMale() {
		 male.click();;
	}

	public WebElement getFemale() {
		return female;
	}

	public void setFemale() {
		 female.click();;
	}

	public WebElement getEnglish() {
		return English;
	}

	public void setEnglish() {
		English.click();
	}

	public WebElement getHindi() {
		return Hindi;
	}

	public void setHindi() {
		Hindi.click();
	}

	public WebElement getFrench() {
		return French;
	}

	public void setFrench() {
		French.click();
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}
	public void setCity(String value) {
		getSelectOptions(city).selectByVisibleText(value);
	}

	public String getCity() {
		return getSelectOptions(city).getFirstSelectedOption().getText();
	}
	/*public WebElement getCity() {
		return city;
	}

	public void setCity(WebElement city) {
		this.city = city;
	}*/

	public WebElement getPhno() {
		return phno;
	}

	public void setPhno(String phno) {
		this.phno.sendKeys(phno);
	}

	public WebElement getAccno() {
		return accno;
	}

	public void setAccno(String accno) {
		this.accno.sendKeys(accno);
	}

	public WebElement getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan.sendKeys(pan);
	}

	public WebElement getCredit() {
		return credit;
	}

	public void setCredit(String credit) {
		this.credit.sendKeys(credit);
	}

	public WebElement getNoofyr() {
		return noofyr;
	}

	public void setNoofyr(String noofyr) {
		this.noofyr.sendKeys(noofyr);
	}

	public WebElement getRoi() {
		return roi;
	}

	public void setRoi(String roi) {
		this.roi.sendKeys(roi);
	}

	public WebElement getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount.sendKeys(amount);;
	}

	/*public WebElement getLoantype() {
		return loantype;
	}

	public void setLoantype(WebElement loantype) {
		this.loantype = loantype;
	}*/

	public void setLoantype(String value) {
		getSelectOptions(loantype).selectByVisibleText(value);
	}

	public String getLoantype() {
		return getSelectOptions(loantype).getFirstSelectedOption().getText();
	}
	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit() {
		submit.click();
	}
	
	
	
}
